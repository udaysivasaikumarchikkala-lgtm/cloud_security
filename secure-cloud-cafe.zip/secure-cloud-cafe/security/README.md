Security folder
- place your policy-as-code and security policies here
- example: sentinel / pulumi rules, custom hardening scripts
