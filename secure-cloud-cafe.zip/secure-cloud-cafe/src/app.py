from flask import Flask, jsonify, request

app = Flask(__name__)

orders = []

@app.route('/')
def home():
    return "Welcome to Cloud Café ☁️"

@app.route('/menu')
def menu():
    return jsonify([
        {"item": "Coffee", "price": 100},
        {"item": "Tea", "price": 80},
        {"item": "Sandwich", "price": 150}
    ])

@app.route('/order', methods=['POST'])
def order():
    data = request.json
    if not data or 'item' not in data or 'customer' not in data:
        return jsonify({"error":"invalid request, require 'item' and 'customer'"}), 400
    orders.append(data)
    return jsonify({"message": "Order received", "order": data}), 201

@app.route('/orders')
def get_orders():
    return jsonify(orders)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
